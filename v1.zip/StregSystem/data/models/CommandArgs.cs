﻿using System;

namespace StregSystem.data.models
{
    public class CommandArgs : EventArgs
    {
        public string Command { get; set; }
    }
}
