﻿using System;

namespace StregSystem.data.models
{
    public class UserArgs : EventArgs
    {
        public User user { get; set; }
    }
}
