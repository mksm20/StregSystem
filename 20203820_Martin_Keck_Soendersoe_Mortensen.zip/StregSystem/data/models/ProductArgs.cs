﻿using System;

namespace StregSystem.data.models
{
    public class ProductArgs : EventArgs
    {
        public Product product { get; set; }
    }
}
